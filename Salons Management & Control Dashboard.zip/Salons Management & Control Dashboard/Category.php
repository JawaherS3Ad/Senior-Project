<?php

    class Category {
    	public static $HAM = 'HAM';
    	public static $SPAM = 'SPAM';
    }

?>