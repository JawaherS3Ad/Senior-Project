<?php
session_start();
include('includes/dbconnection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset'])) {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password == $confirm_password) {
        // Hash the new password
        $hashed_password = md5($new_password);

        // Check if email exists and update the password
        $sql = "SELECT * FROM salons WHERE email=:email";
        $query = $dbh->prepare($sql);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->execute();
        if ($query->rowCount() > 0) {
            $updateSql = "UPDATE salons SET password=:new_password WHERE email=:email";
            $updateQuery = $dbh->prepare($updateSql);
            $updateQuery->bindParam(':new_password', $hashed_password, PDO::PARAM_STR);
            $updateQuery->bindParam(':email', $email, PDO::PARAM_STR);
            $updateQuery->execute();
            echo "<script>alert('Password has been reset successfully.'); window.location.href='salon_login.php';</script>";
        } else {
            echo "<script>alert('No account found with that email.');</script>";
        }
    } else {
        echo "<script>alert('Passwords do not match.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <?php @include("includes/head.php"); ?>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f6f9;
        }
        .login-box {
            width: 360px;
            margin: auto;
        }
        .card {
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Reset your password</p>
                <form action="" method="post">
                    Email: <input type="email" name="email" class="form-control" required><br>
                    New Password: <input type="password" name="new_password" class="form-control" required><br>
                    Confirm Password: <input type="password" name="confirm_password" class="form-control" required><br>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" name="reset" class="btn btn-primary btn-block">Reset Password</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php @include("includes/foot.php"); ?>
</body>
</html>
