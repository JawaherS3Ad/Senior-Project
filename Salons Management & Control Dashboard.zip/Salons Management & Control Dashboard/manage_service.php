<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) 
{
  header('location:logout.php');
} else
{
    if(isset($_REQUEST['del']))
{
$service_id=intval($_GET['del']);
$sql = "DELETE from salon_services  WHERE  service_id=:service_id ";
$query = $dbh->prepare($sql);
$query -> bindParam(':service_id',$service_id, PDO::PARAM_STR);
$query -> execute();
$msg="Deleted successfully";
}
  ?>
<html>
<head>
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.9.55/css/materialdesignicons.min.css">
</head>
  <?php @include("includes/head.php"); ?>
  <body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
      <!-- Navbar -->
      <?php @include("includes/header.php"); ?>
      <!-- /.navbar -->
      <!-- Side bar and Menu -->
      <?php @include("includes/sidebar.php"); ?>
      <!-- /.sidebar and menu -->
      
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <br>
        <div class="card">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Manage Service</h3>
              </div>
              <?php
              echo $msg;
              ?>
              <div class="card-body">
                <!-- Date -->
                <table class="table align-items-center table-flush table-hover table-bordered" id="dataTableHover" style="float: left;">
                    <thead >
                      <tr >
                        <th>#</th>
                        <th class="text-center">Service name</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Duration </th>
                        <th class="text-center">Describtion</th>
                        <th class="text-center">الحدث</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sql = "SELECT * from salon_services";
                      $query = $dbh -> prepare($sql);
                      $query->execute();
                      $results=$query->fetchAll(PDO::FETCH_OBJ);
                      $cnt=1;
                      if($query->rowCount() > 0)
                      {
                        foreach($results as $row)
                        { 
                          $status=$row->block_status;
                          ?>
                          <tr>
                            <td class="text-center"><?php echo htmlentities($cnt);?></td>
                            <td>
                              <img src="company/<?php  echo $row->image_url;?>" width="20%" alt="image">
                              &nbsp;&nbsp;&nbsp;&nbsp;<?php echo htmlentities($row->services_name);?></a>
                            </td>
                            <?php
                            ?>
                            <td class="text-center"><?php echo htmlentities($row->price);?></td>
                            <td class="text-center"><?php echo htmlentities($row->duration);?></td>
                            <td class="text-center"><?php echo htmlentities($row->description);?></td>
                            <td class="text-center">
                              <a href="edit_service.php?id=<?php echo $row->service_id;?>" title="click to edit"><i class="mdi mdi-pencil-box-outline" aria-hidden="true"></i></a>
                              <a href="manage_service.php?del=<?php echo $row->service_id;?>" onclick="return confirm('Do you want to delete this service');"><i class="mdi mdi-delete"></i></i></a>
                            </td>
                          </tr>
                          <?php 
                          $cnt=$cnt+1;
                        }
                      } ?>
                    </tbody>
                  </table>
                
            </div>

            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>
    <?php @include("includes/foot.php"); ?>
  </body>
  </html>
  <?php
} ?>
