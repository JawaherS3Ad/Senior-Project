<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) 
{
  header('location:logout.php');
} else
{
    if(isset($_POST['save']))
    {
      $name=$_POST['name'];
      $password=md5($_POST['password']);
      $location=$_POST['location'];
      $phone=$_POST['phone'];
      $email=$_POST['email'];
      $url=$_POST['url'];
      $vimage1=$_FILES["img1"]["name"];
      move_uploaded_file($_FILES["img1"]["tmp_name"],"company/".$_FILES["img1"]["name"]);
      $details=$_POST['details'];
    
      $sql="INSERT INTO salons VALUES(NULL,'$name','$password','$location','$phone','$email','$url','$details','$vimage1',NULL)";
      $query = $dbh->prepare($sql);
      $query->execute();
      $lastInsertId = $dbh->lastInsertId();
      if($lastInsertId)
      {
        echo '<script>alert("Added successfully")</script>';
      }
      else 
      {
        echo '<script>alert("Error")</script>'; 
      }
    }
  ?>

  <?php @include("includes/head.php"); ?>
  <body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
      <!-- Navbar -->
      <?php @include("includes/header.php"); ?>
      <!-- /.navbar -->
      <!-- Side bar and Menu -->
      <?php @include("includes/sidebar.php"); ?>
      <!-- /.sidebar and menu -->
      
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <br>
        <div class="card">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add salon</h3>
              </div>
              <div class="card-body">
                <!-- Date -->

                <form class="forms-sample" method="post" enctype="multipart/form-data" class="form-horizontal">
            <div class=" col -md-12 card">
              
              <div class="col-md-12 mt-4">
                <div class="row ">
                  <div class="form-group col-md-6 ">
                  <center>
                    <label for="exampleInputPassword1" style="float: left;">Salon name<span style="color:red">*</span></label>
                    <input type="text" name="name" class="form-control"  placeholder="Salon name" required>
                     
                  </div>
                  <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Password<span style="color:red">*</span></label>
                    <input type="password" name="password" class="form-control"  placeholder="password" required>
                  </div>
                </div>

                <div class="col-md-12 mt-4">
                <div class="row ">
                  <div class="form-group col-md-6 ">
                  <center>
                    <label for="exampleInputPassword1" style="float: left;">Mobile number<span style="color:red">*</span></label>
                    <input type="number" name="phone" class="form-control"  placeholder="Mobile number" required>
                     
                  </div>
                  <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Salon email<span style="color:red">*</span></label>
                    <input type="email" name="email" class="form-control"  placeholder="Salon email" required>
                  </div>
                </div>

                <div class="col-md-12 mt-4">
                <div class="row ">
                  <div class="form-group col-md-6 ">
                  <center>
                    <label for="exampleInputPassword1" style="float: left;">Website url<span style="color:red">*</span></label>
                    <input type="text" name="url" class="form-control"  placeholder="Salon Website url" required>
                     
                  </div>
                  <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Salon location<span style="color:red">*</span></label>
                    <input type="text" name="location" class="form-control"  placeholder="Salon location" required>
                  </div>
                  
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Salon describtion<span style="color:red">*</span></label>
                    <textarea class="form-control" name="details" rows="3" required></textarea>
                  </div>
                      <div class="row ">
                       <div class="form-group col-md-4 pl-md-0">
                        <label class="col-sm-12 pl-0 pr-0 " style="float: left;">Salon image <span style="color:red">*</label>
                          <div class="col-sm-12 pl-0 pr-0">
                            <input type="file" name="img1" class="file-upload-default">
                            <div class="input-group ">
                              <input type="text" class="form-control file-upload-info" disabled placeholder="Upload image">
                              <span class="input-group-append">
                                <button class="file-upload-browse btn btn-gradient-primary" style="" type="button">Upload</button>
                              </span>
                              
                            </div>
                            
                          </div>
                          
                        </div> 
                        
                          
                          </div>
                 <button type="submit" style="float: left;" name="save" class="btn btn-primary  mr-2 mb-4">Save</button>

                          <div class="row">
                  
                          </div></div></div>
           </form>
            </div>

            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>
    <?php @include("includes/foot.php"); ?>
  </body>
  </html>
  <?php
} ?>
