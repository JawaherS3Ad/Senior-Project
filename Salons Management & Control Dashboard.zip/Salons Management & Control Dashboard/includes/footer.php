<footer class="main-footer">
  <strong>Copyright &copy; <script>document.write(new Date().getFullYear());</script> <a href="http://salon.com">Salon</a>.</strong>
  All rights reserved.
</footer>