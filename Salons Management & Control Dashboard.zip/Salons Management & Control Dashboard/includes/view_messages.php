<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) 
{
  header('location:logout.php');
} else
// {
//     if(isset($_GET['id']))
// {
// $id=$_GET['id'];
// $sql = "UPDATE appointment set appointment_status = 1 where appointment_id='$id'";
// $query = $dbh->prepare($sql);
// $query -> execute();
// }
// if(isset($_GET['rid']))
// {
// $rid=$_GET['rid'];
// $sql2 = "UPDATE appointment set appointment_status = 0 where appointment_id='$rid'";
// $query2 = $dbh->prepare($sql2);
// $query2 -> execute();
// }
  ?>
<html>
<head>
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.9.55/css/materialdesignicons.min.css">
</head>
<?php @include("includes/head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php @include("includes/header.php"); ?>
    <!-- /.navbar -->
    <!-- Side bar and Menu -->
    <?php @include("includes/sidebar.php"); ?>
    <!-- /.sidebar and menu -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <br>
      <div class="card">
        <div class="col-md-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Users messages</h3>
            </div>
            <?php
            echo $msg;
            ?>
            <div class="card-body">
            <div class="mb-3">
    <input type="text" id="searchInput" class="form-control" placeholder="Search">
  </div>
              <!-- Date -->
              <table class="table align-items-center table-flush table-hover table-bordered" id="dataTableHover" style="float: left;">
              <thead>
  <tr>
    <th>#</th>
    <th class="text-center">User name</th>
    <th class="text-center">Service name</th>
    <th class="text-center">Appointment date</th>
    <th class="text-center">Appointment time</th>
    <th class="text-center">Feedback</th>
    <th class="text-center">Appointment status</th>
    <th class="text-center">Action</th>
  </tr>
</thead>
                <tbody>
                  <?php
                  $sql = "SELECT cs.email, cs.message, u.full_name
                  FROM customer_support cs
                  JOIN users u ON cs.email = u.email";
          $query = $dbh->prepare($sql);
          $query->execute();
          $results = $query->fetchAll(PDO::FETCH_OBJ);
          $cnt = 1;
                  if ($query->rowCount() > 0) {
                    foreach ($results as $row) {
                       
                        ?>
                        <tr>
                          <td class="text-center"><?php echo htmlentities($cnt); ?></td>
                          <td class="text-center"><?php echo htmlentities($row->full_name); ?></td>
                          <td class="text-center"><?php echo htmlentities($row->email); ?></td>
                          <td class="text-center"><?php echo htmlentities($row->message); ?></td>
                          
                        <?php
                        $cnt = $cnt + 1;
                      }
                  } ?>
                </tbody>
              </table>
            </div>

            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>
    <?php @include("includes/foot.php"); ?>
  </body>
</html>
<script>
  // Get the search input element
  const searchInput = document.getElementById('searchInput');

  // Add an event listener to listen for input changes
  searchInput.addEventListener('input', function() {
    const searchTerm = searchInput.value.toLowerCase(); // Get the search term and convert to lowercase

    // Get all table rows
    const rows = document.querySelectorAll('#dataTableHover tbody tr');

    // Loop through each row and hide/show based on search term
    rows.forEach(function(row) {
      const fullName = row.querySelector('.text-center:nth-child(2)').textContent.toLowerCase(); // Get the full name column value
      const serviceName = row.querySelector('.text-center:nth-child(3)').textContent.toLowerCase(); // Get the service name column value

      if (fullName.includes(searchTerm) || serviceName.includes(searchTerm)) {
        row.style.display = ''; // Show the row if search term matches
      } else {
        row.style.display = 'none'; // Hide the row if search term doesn't match
      }
    });
  });
</script>
  <?php
} ?>
