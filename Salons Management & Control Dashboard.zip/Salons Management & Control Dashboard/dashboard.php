<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) {
  header('location:logout.php');
} 
?>
<!DOCTYPE html>
<html>
<?php @include("includes/head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php @include("includes/header.php"); ?>
    <!-- Main Sidebar Container -->
    <?php @include("includes/sidebar.php"); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">Dashboard</h1>
              <table class="table align-items-center table-flush table-hover table-bordered" id="dataTableHover" style="float: left;">
                    <thead >
                 
                        <tr>
                        <th class="text-center">salon name</th>
            <th class="text-center"> reviews comment</th>
            <th class="text-center">  classify commant</th>
        </tr>
                    </thead>
                  
                    <tbody>
                   
    
                    <?php
include './autoload.php';

$tokenizer = new HybridLogic\Classifier\Basic;
$classifier = new HybridLogic\Classifier($tokenizer);

 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salon";

      // الاتصال بقاعدة البيانات وتدريب المصنف
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT category, document FROM trainingset";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
          $trainingData = ["Satisfied" => 0, "Not Satisfied" => 0];
          while ($row = $result->fetch_assoc()) {
              // التبديل بين category و document
              $classifier->train($row["category"], $row["document"]);
              $trainingData[$row["category"]]++;
          }
      } else {
          echo "No training data found<br>";
      }

      $conn->close();

       // اختبار المصنف ببعض البيانات
       /*$testComments = [
        "I had a great time at the salon",
        "The service was terrible",
        "Amazing experience",
        "Not what I expected",
        "Loved it!",
        "Very disappointed"
    ];

    foreach ($testComments as $comment) {
        $testClassification = $classifier->classify($comment);
        echo "Test Comment: \"$comment\" -> Classification: " . key($testClassification) . "<br>";
    }*/

// Reconnect to the database to fetch comments for classification
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT salons.salon_name, salon_rating.reviews_comment, salon_rating.salon_id FROM salon_rating JOIN salons ON salons.salon_id = salon_rating.salon_id";
$result = $conn->query($sql);

 
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $text = $row["reviews_comment"];
        $salon_name = $row["salon_name"];
        $salon_id = $row["salon_id"];
        
        // تأكد من أن salon_id غير مفقود
        if (!isset($salon_id)) {
            echo "Error: salon_id is missing for comment: $text<br>";
            continue;
        }

        $classification = $classifier->classify($text);
        $classifiedResult = key($classification) === 'Satisfied' ? 'Satisfied' : 'Not Satisfied';

        // طباعة التصنيف لتصحيح الأخطاء
        //echo "Salon: $salon_name, Comment: $text, Classification: $classifiedResult<br>";

        // تحديث التصنيف في قاعدة البيانات
        $updateSql = "UPDATE salon_rating SET classification='$classifiedResult' WHERE salon_id='$salon_id'";
          if ($conn->query($updateSql) === FALSE) {
              echo "Error updating record: " . $conn->error . "<br>";
          }

        $row["classification"] = $classifiedResult;

        echo '<tr>';
        echo '<td>' . $salon_name . '</td>';
        echo '<td>' . $text . '</td>';
        echo '<td>' . $classifiedResult . '</td>';
        echo '</tr>';
    }
} else {
    echo "No comments found<br>";
}
  
      $conn->close();
        // $conn->close();
        ?>
          </tbody>
                  </table>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      
<?php
      
// Initialize counts
$satisfiedCount = 0;
$notSatisfiedCount = 0;

// Connect to database
$conn = new mysqli("localhost", "root", "", "salon");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch classification counts from database
$sql = "SELECT classification, COUNT(*) as count FROM salon_rating GROUP BY classification";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row["classification"] === 'Satisfied') {
            $satisfiedCount = $row["count"];
        } else if ($row["classification"] === 'Not Satisfied') {
            $notSatisfiedCount = $row["count"];
        }
    }
} else {
    error_log("No data found for classification.");
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pie Chart Display</title>
    <style>
        body {
            background-color: transparent;
        }
        #chartContainer {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            margin-top: 20px;
        }
        .chart {
            width: 45%;
            height: 500px;
        }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawCharts);

        function drawCharts() {
            drawSatisfactionChart();
            drawSalonChart();
        }

        function drawSatisfactionChart() {
            var data = google.visualization.arrayToDataTable([
                ['Category', 'Count'],
                ['Satisfied', <?php echo $satisfiedCount; ?>],
                ['Not Satisfied', <?php echo $notSatisfiedCount; ?>]
            ]);

            var options = {
                title: 'Customer Satisfaction Overview',
                is3D: true,
                colors: ['#28a745', '#dc3545'],
                backgroundColor: 'transparent'
            };

            var chart = new google.visualization.PieChart(document.getElementById('satisfactionPieChart'));
            chart.draw(data, options);
        }

        function drawSalonChart() {
            var data = google.visualization.arrayToDataTable([
                ['Salon Name', 'Number of Comments'],
                <?php
                // Connect to database again to fetch salon review counts
                $con = new mysqli("localhost","root","","salon");
                if ($con->connect_error) {
                    die("Connection failed: " . $con->connect_error);
                }

                $sql = "SELECT salons.salon_name, COUNT(salon_rating.reviews_comment) AS num_comments FROM salon_rating JOIN salons ON salons.salon_id = salon_rating.salon_id GROUP BY salons.salon_name";
                $result = $con->query($sql);
                $dataExists = false;

                while ($row = $result->fetch_assoc()) {
                    echo "['" . $row['salon_name'] . "', " . $row['num_comments'] . "],";
                    $dataExists = true;
                }

                if (!$dataExists) {
                    echo "['No data', 0]";
                }

                $con->close();
                ?>
            ]);

            var options = {
                title: 'Salon Reviews Distribution',
                is3D: true,
                backgroundColor: 'transparent'
            };

            var chart = new google.visualization.PieChart(document.getElementById('salonPieChart'));
            chart.draw(data, options);
        }
    </script>
</head>
<body>
    <div id="chartContainer">
        <div id="satisfactionPieChart" class="chart"></div>
        <div id="salonPieChart" class="chart"></div>
    </div>
</body>
</html>
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <?php @include("includes/foot.php"); ?>
</body>
</html>
