<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) 
{
  header('location:logout.php');
} else
{
    if(isset($_POST['save']))
    {
      $name=$_POST['name'];
      $price=$_POST['price'];
      $duration=$_POST['duration'];
      $details=$_POST['details'];
    
      $id=intval($_GET['id']);

      $sql="update salon_services set services_name='$name',description='$details', price='$price', duration='$duration'
      where service_id=:id";
      $query = $dbh->prepare($sql);
      $query->bindParam(':id',$id,PDO::PARAM_STR);
      $query->execute();
      
      $msg="Updated successfully";
    }
  ?>

  <?php @include("includes/head.php"); ?>
  <body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
      <!-- Navbar -->
      <?php @include("includes/header.php"); ?>
      <!-- /.navbar -->
      <!-- Side bar and Menu -->
      <?php @include("includes/sidebar.php"); ?>
      <!-- /.sidebar and menu -->
      
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <br>
        <div class="card">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Service</h3>
              </div>
              <div class="card-body">
                <!-- Date -->
                <?php
              echo $msg;
              ?>
                <form class="forms-sample" method="post" enctype="multipart/form-data" class="form-horizontal">
            <div class=" col -md-12 card">
              
              <div class="col-md-12 mt-4">
              
              <?php 
              $id=intval($_GET['id']);
              $sql ="SELECT * from salon_services where service_id=:id";
              $query = $dbh -> prepare($sql);
              $query-> bindParam(':id', $id, PDO::PARAM_STR);
              $query->execute();
              $results=$query->fetchAll(PDO::FETCH_OBJ);
              $cnt=1;
              if($query->rowCount() > 0)
              {
                foreach($results as $result)
                { 
                  ?>
                <div class="row ">
                  <div class="form-group col-md-6 ">
                  <center>
                    <label for="exampleInputPassword1" style="float: left;">Service name<span style="color:red">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlentities($result->services_name)?>"  placeholder="Salon name" required>
                     
                  </div>
                  <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Price<span style="color:red">*</span></label>
                    <input type="number" name="price" class="form-control" value="<?php echo htmlentities($result->price)?>" placeholder="" required>
                  </div>
                </div>

                <div class="col-md-12 mt-4">
                <div class="row ">
                  <div class="form-group col-md-6 ">
                  <center>
                    <label for="exampleInputPassword1" style="float: left;">Duration<span style="color:red">*</span></label>
                    <input type="text" name="duration" class="form-control" value="<?php echo htmlentities($result->duration)?>"  placeholder="Salon name" required>
                     
                  </div>
                  <div class="form-group col-md-6">
                    <label for="exampleInputName1" style="float: left;">Description<span style="color:red">*</span></label>
                   <textarea class="form-control" name="details" rows="3" required> <?php echo htmlentities($result->description)?></textarea>
                    
                  </div>
                </div>

               
                 <button type="submit" style="float: left;" name="save" class="btn btn-primary  mr-2 mb-4">Save</button>

                          <div class="row">
                  
                          </div></div></div>
                          <?php 
        }
      }?>
           </form>
            </div>

            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>
    <?php @include("includes/foot.php"); ?>
  </body>
  </html>
  <?php
} ?>
