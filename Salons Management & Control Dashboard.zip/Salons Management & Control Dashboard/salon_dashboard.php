<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['salon_id']==0)) {
  header('location:salon_logout.php');
} 
?>
<!DOCTYPE html>
<html>
<?php @include("includes/head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php @include("salon_includes/header.php"); ?>
    <!-- Main Sidebar Container -->
    <?php @include("salon_includes/sidebar.php"); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
      <table class="table align-items-center table-flush table-hover table-bordered" id="dataTableHover" style="float: left;">
                    <thead >
                 
                        <tr>
                          <!-- <th class="text-center">salon id</th> -->
            <th class="text-center"> reviews comment</th>
            <th class="text-center">  classify commant</th>
        </tr>
                    </thead>
                  
                    <tbody>
                   
    
                    <?php
include './autoload.php';

$tokenizer = new HybridLogic\Classifier\Basic;
$classifier = new HybridLogic\Classifier($tokenizer);

 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salon";
     
        $conn = new mysqli("localhost", "root", "", "salon");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT category, document FROM trainingset";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // train model
          while ($row = $result->fetch_assoc()) {
              $category = $row["document"];
              $document = $row["category"];
              $classifier->train($document, $category);
          }
      } else {
          echo "no data";
      }

      $conn->close();

// Reconnect to the database to fetch comments for classification
$conn = new mysqli($servername, $username, $password, $dbname);

//$sql = "SELECT salons.salon_name salon_name, salon_rating.reviews_comment reviews_comment FROM salon_rating JOIN salons ON salons.salon_id = salon_rating.salon_id and WHERE salon_id = '" . $_SESSION['salon_id'] . "'";
$sql = "SELECT salons.salon_name, salon_rating.reviews_comment
        FROM salon_rating
        JOIN salons ON salons.salon_id = salon_rating.salon_id
        WHERE salon_rating.salon_id = '" . $_SESSION['salon_id'] . "'";
$result = $conn->query($sql);

 
if ($result->num_rows > 0) {
  // Execute the algorithm on the comments and display the results in the table
  while ($row = $result->fetch_assoc()) {
      $text = $row["reviews_comment"];
      $salon_name = $row["salon_name"];
      $classification = $classifier->classify($text);
    
      echo '<tr>';
//      echo '<td>' .$salon_name.   '</td>';
      echo '<td>' . $text . '</td>';
      echo '<td>' . key($classification) . '</td>';
      echo '</tr>';
  }
} else {
  echo "NO DATA";
}
  
      $conn->close();
        // $conn->close();
        ?>
          </tbody>
                  </table>
        

    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <?php @include("includes/foot.php"); ?>
</body>
</html>

